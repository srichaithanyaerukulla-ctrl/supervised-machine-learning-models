from pathlib import Path
import numpy as np
import pandas as pd
import statsmodels.api as sm
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.neighbors import KNeighborsRegressor, KNeighborsClassifier
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, accuracy_score, precision_score, recall_score, f1_score, roc_auc_score

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
OUTPUT_DIR = DATA_DIR

def make_pipeline(model, scale=False):
    steps = [("imputer", SimpleImputer(strategy="median"))]
    if scale:
        steps.append(("scaler", StandardScaler()))
    steps.append(("model", model))
    return Pipeline(steps)

def load_data():
    df = sm.datasets.star98.load_pandas().data.copy()
    df["SUCCESS_RATE"] = df["NABOVE"] / (df["NABOVE"] + df["NBELOW"])
    df["HIGH_SUCCESS"] = (df["SUCCESS_RATE"] >= df["SUCCESS_RATE"].median()).astype(int)
    features = [c for c in df.columns if c not in ["NABOVE", "NBELOW", "SUCCESS_RATE", "HIGH_SUCCESS"]]
    return df, features

def run_models():
    df, features = load_data()
    X = df[features]
    y_reg = df["SUCCESS_RATE"]
    y_clf = df["HIGH_SUCCESS"]

    Xtr, Xte, ytr, yte = train_test_split(X, y_reg, test_size=0.20, random_state=42)
    regression_models = {
        "Linear Regression": (LinearRegression(), True),
        "Decision Tree Regressor": (DecisionTreeRegressor(max_depth=4, random_state=42), False),
        "Random Forest Regressor": (RandomForestRegressor(n_estimators=300, max_depth=6, random_state=42), False),
        "KNN Regressor": (KNeighborsRegressor(n_neighbors=7), True),
    }
    reg_rows = []
    for name, (model, scale) in regression_models.items():
        model = make_pipeline(model, scale)
        model.fit(Xtr, ytr)
        pred = model.predict(Xte)
        reg_rows.append({"Model": name, "MAE": mean_absolute_error(yte, pred), "RMSE": mean_squared_error(yte, pred) ** 0.5, "R2": r2_score(yte, pred)})
    pd.DataFrame(reg_rows).to_csv(OUTPUT_DIR / "regression_model_comparison.csv", index=False)

    Xtr, Xte, ytr, yte = train_test_split(X, y_clf, test_size=0.20, random_state=42, stratify=y_clf)
    classification_models = {
        "Logistic Regression": (LogisticRegression(max_iter=5000, random_state=42), True),
        "Decision Tree Classifier": (DecisionTreeClassifier(max_depth=4, random_state=42), False),
        "Random Forest Classifier": (RandomForestClassifier(n_estimators=300, max_depth=6, random_state=42), False),
        "KNN Classifier": (KNeighborsClassifier(n_neighbors=7), True),
    }
    clf_rows = []
    for name, (model, scale) in classification_models.items():
        model = make_pipeline(model, scale)
        model.fit(Xtr, ytr)
        pred = model.predict(Xte)
        proba = model.predict_proba(Xte)[:, 1]
        clf_rows.append({"Model": name, "Accuracy": accuracy_score(yte, pred), "Precision": precision_score(yte, pred), "Recall": recall_score(yte, pred), "F1": f1_score(yte, pred), "ROC_AUC": roc_auc_score(yte, proba)})
    pd.DataFrame(clf_rows).to_csv(OUTPUT_DIR / "classification_model_comparison.csv", index=False)

if __name__ == "__main__":
    run_models()
    print("Model training and evaluation completed.")
