from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]

def test_regression_comparison_has_required_models():
    df = pd.read_csv(ROOT / "data/regression_model_comparison.csv")
    required = {"Linear Regression", "Decision Tree Regressor", "Random Forest Regressor", "KNN Regressor"}
    assert required.issubset(set(df["Model"]))
    assert df[["MAE","RMSE","R2"]].notna().all().all()

def test_classification_comparison_has_required_models():
    df = pd.read_csv(ROOT / "data/classification_model_comparison.csv")
    required = {"Logistic Regression", "Decision Tree Classifier", "Random Forest Classifier", "KNN Classifier"}
    assert required.issubset(set(df["Model"]))
    assert df[["Accuracy","Precision","Recall","F1","ROC_AUC"]].notna().all().all()

def test_metrics_are_in_valid_ranges():
    r = pd.read_csv(ROOT / "data/regression_model_comparison.csv")
    c = pd.read_csv(ROOT / "data/classification_model_comparison.csv")
    assert (r["MAE"] >= 0).all() and (r["RMSE"] >= 0).all()
    assert (r["R2"] <= 1).all()
    assert ((c[["Accuracy","Precision","Recall","F1","ROC_AUC"]] >= 0) & (c[["Accuracy","Precision","Recall","F1","ROC_AUC"]] <= 1)).all().all()
