# NSDC Week 2 — Supervised Machine Learning Models

## Task
Build supervised machine-learning models using Scikit-learn, train and evaluate regression and classification algorithms, and compare their performance with appropriate metrics.

## Dataset
STAR98 Educational Dataset loaded through the public `statsmodels` dataset interface. The modeling target `SUCCESS_RATE` is calculated as `NABOVE / (NABOVE + NBELOW)`. For classification, `HIGH_SUCCESS` is defined as 1 when `SUCCESS_RATE` is at or above the sample median and 0 otherwise. `NABOVE` and `NBELOW` are excluded from model features to avoid directly supplying the target components as inputs.

## Models implemented
- Linear Regression
- Logistic Regression
- Decision Tree (regression + classification)
- Random Forest (regression + classification)
- K-Nearest Neighbors (regression + classification)

## Evaluation
Regression: MAE, RMSE, R².
Classification: Accuracy, Precision, Recall, F1, ROC-AUC.

## Reproducibility
```bash
pip install -r requirements.txt
python src/model_training.py
python -m pytest -q
```

## Generated outputs
- `data/regression_model_comparison.csv`
- `data/classification_model_comparison.csv`
- `visualizations/`
- `docs/Week2_Supervised_Machine_Learning_Report.docx`

Dataset values are used for educational model-development practice.
